/**
 */

tinyMCE.addI18n('en.apiemotions',{
    desc : 'Insert API emotions',
    delta_width : '0',
    delta_height : '0'
});