######################
01-03-2008
APIemotions plugin v1.0 created for TinyMCE v3.0.1
by luciorota
######################

This plugin allows you and your site's users
to add API emotions/smiles.

Installation instructions:
  * Copy the "apiemotions" directory to the plugins directory of TinyMCE
  * The plugin should be enabled (read TinyMCE instructions)
  * Add "apiemotions" button to TinyMCE toolbar (read TinyMCE instructions)

That's all!