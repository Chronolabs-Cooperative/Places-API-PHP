/**
 */

tinyMCE.addI18n('en.apiimagemanager',{
    desc : 'API Advanced Imagemanager',
    delta_width : '0',
    delta_height : '0'
});
tinyMCE.addI18n('en.apiimagebrowser',{
    desc : 'API Imagebrowser',
    delta_width : '0',
    delta_height : '0'
});
