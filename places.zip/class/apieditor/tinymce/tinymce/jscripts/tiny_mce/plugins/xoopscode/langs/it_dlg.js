tinyMCE.addI18n('it.apicode_dlg',{
    apicode_title:"Inserisci codice",
    apicode_desc:"Inserisci codice",
    apicode_sub:"Digita/Incolla il codice:"
});
