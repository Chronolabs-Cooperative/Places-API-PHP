/**
 */

tinyMCE.addI18n('en.apimlcontent_dlg',{
    title : 'Insert multi-language content',
    subtitle : 'Select a language and type/paste the content in the box below:',
    sellang : 'Select language',
    chooselang : 'You must choose a language',
    maxstring : ' character(s) of %maxchar% entered',
    alertmaxstring : 'You have reached the maximum number of characters',
    delta_width : 100,
    delta_height : 100
});