tinyMCE.addI18n('en.apiquote',{
    quote_desc:"Insert quote"
});
