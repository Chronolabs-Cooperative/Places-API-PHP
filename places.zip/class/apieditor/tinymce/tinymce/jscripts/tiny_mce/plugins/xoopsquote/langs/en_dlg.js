tinyMCE.addI18n('en.apiquote_dlg',{
    apiquote_title:"Insert quote",
    apiquote_desc:"Insert quote",
    apiquote_sub:"Paste the text you want to quote in the box below:"
});
