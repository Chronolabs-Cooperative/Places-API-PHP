tinyMCE.addI18n('it.apiemotions_dlg',{
    title : 'Inserisci Faccine/Emoticon di API',
    tab_emotionsbrowser: 'Faccine/Emoticon',
    tab_emotionsadmin: 'Aggiungi Faccine/Emoticon',
    error_noemotions: 'Non ci sono Faccine/Emoticon nel database !!!'
});
