#######################################
 MLcontent plugin for TinyMCE
 by luciorota (original idea by ralf57)
 2008-07-02
#######################################

This plugin allows you and your site's users to add multi-language content into tinyMCE's area.

Compatible with "THE EASIEST MULTILANGUAGE HACK" by GIJOE and/or "Xlanguage" module.

NOTE
You MUST have "THE EASIEST MULTILANGUAGE HACK" by GIJOE applied to your api installation before
enabling and using this plugin.

The hack "THE EASIEST MULTILANGUAGE HACK" by GIJOE can be found at http://www.peak.ne.jp/api/
The "Xlanguage" mudule can be found at http://api.org.cn/modules/wfdownloads/singlefile.php?cid=8&lid=517

That's all!
