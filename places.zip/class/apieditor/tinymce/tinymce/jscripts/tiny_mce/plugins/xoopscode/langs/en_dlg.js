tinyMCE.addI18n('en.apicode_dlg',{
    apicode_title:"Insert code",
    apicode_desc:"Insert code",
    apicode_sub:"Paste the code you want to insert in the box below:"
});
