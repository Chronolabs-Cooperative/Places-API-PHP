tinyMCE.addI18n('it.apiemotions',{
    desc : 'Inserisci Faccine/Emoticon di API',
    delta_width : '0',
    delta_height : '0'
});
