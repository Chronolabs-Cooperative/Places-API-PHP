tinyMCE.addI18n('it.apiquote',{
    quote_desc:"Inserisci citazione/quote"
});
