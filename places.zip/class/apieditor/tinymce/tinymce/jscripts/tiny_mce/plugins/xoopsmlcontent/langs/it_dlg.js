tinyMCE.addI18n('it.apimlcontent_dlg',{
    title : 'Inserisci contenuto multi-lingua',
    subtitle : 'Seleziona lingua e digita/incolla il testo:',
    sellang : 'Seleziona lingua',
        chooselang : 'You must choose a language',
        maxstring : ' character(s) of %maxchar% entered',
        alertmaxstring : 'You have reached the maximum number of characters',
        delta_width : 100,
        delta_height : 100
});
