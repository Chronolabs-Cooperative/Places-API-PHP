/**
 */

tinyMCE.addI18n('en.apiemotions_dlg',{
    title : 'Insert API Emoticons',
    tab_emotionsbrowser: 'Emoticons',
    tab_emotionsadmin: 'Add Emoticons',
    error_noemotions: 'No emotions in database !!!'
});