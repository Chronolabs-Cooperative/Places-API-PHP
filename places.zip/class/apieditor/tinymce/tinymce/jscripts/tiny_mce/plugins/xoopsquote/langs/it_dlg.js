tinyMCE.addI18n('it.apiquote_dlg',{
    apiquote_title:"Inserisci citazione/quote",
    apiquote_desc:"Inserisci citazione/quote",
    apiquote_sub:"Digita/Incolla il testo che desideri citare/quote:"
});
