tinyMCE.addI18n('en.apicode',{
    code_desc:"Insert code"
});
