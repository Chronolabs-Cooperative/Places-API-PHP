/**
 */

tinyMCE.addI18n('en.apimlcontent',{
    desc : 'Insert multi-language content',
    delta_width : '0',
    delta_height : '0'
});