tinyMCE.addI18n('it.apicode',{
    code_desc:"Inserisci codice"
});
