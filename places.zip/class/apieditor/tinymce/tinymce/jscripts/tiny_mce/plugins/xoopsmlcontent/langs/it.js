tinyMCE.addI18n('it.apimlcontent',{
    desc : 'Inserisci contenuto multi-lingua',
    delta_width : '0',
    delta_height : '0'

});
