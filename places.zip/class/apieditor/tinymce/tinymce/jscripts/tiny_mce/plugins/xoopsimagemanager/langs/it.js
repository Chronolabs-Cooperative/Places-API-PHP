tinyMCE.addI18n('it.apiimagemanager',{
    desc : 'Inserisci/modifica immagine API',
    delta_width : '0',
    delta_height : '0'
});
tinyMCE.addI18n('it.apiimagebrowser',{
    desc : 'Inserisci/gestisci immagini API',
    delta_width : '0',
    delta_height : '0'
});
